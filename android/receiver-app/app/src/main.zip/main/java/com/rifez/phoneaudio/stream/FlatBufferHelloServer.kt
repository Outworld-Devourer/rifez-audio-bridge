package com.rifez.phoneaudio.stream

import android.util.Log
import com.rifez.phoneaudio.protocol.FlatBufferControlProtocol
import com.rifez.phoneaudio.protocol.FlatBufferFrameIO
import com.rifez.phoneaudio.service.ReceiverStateRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.cancel
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.net.ServerSocket
import java.net.Socket
import java.net.SocketException

class FlatBufferHelloServer {

    private var serverSocket: ServerSocket? = null
    private var serverJob: Job? = null
    private var scope: CoroutineScope? = null

    @Volatile
    private var currentControlSocket: Socket? = null

    fun start(port: Int) {
        stop()

        scope = CoroutineScope(Dispatchers.IO)
        serverJob = scope?.launch {
            try {
                serverSocket = ServerSocket(port)
                Log.d(TAG, "FlatBuffer control server listening on port $port")

                while (isActive) {
                    val socket = serverSocket?.accept() ?: break

                    try {
                        currentControlSocket?.close()
                    } catch (_: Exception) {
                    }
                    currentControlSocket = socket

                    Log.d(TAG, "FlatBuffer client connected from ${socket.inetAddress?.hostAddress}:${socket.port}")

                    try {
                        val input = socket.getInputStream()
                        val output = socket.getOutputStream()

                        while (true) {
                            val requestFrame = FlatBufferFrameIO.readFrame(input) ?: break

                            when (val message = FlatBufferControlProtocol.parseIncoming(requestFrame)) {
                                is FlatBufferControlProtocol.IncomingMessage.Hello -> {
                                    val clientName = message.clientName.ifBlank { "Unknown PC" }
                                    ReceiverStateRepository.setConnected(pcName = clientName)
                                    ReceiverStateRepository.setControlConnection(
                                        connected = true,
                                        pcName = clientName
                                    )
                                    Log.d(TAG, "FlatBuffer HELLO received from $clientName")

                                    val receiverName = ReceiverStateRepository.runtimeState.value.deviceName
                                    val responseFrame =
                                        FlatBufferControlProtocol.buildHelloResponse(receiverName)
                                    FlatBufferFrameIO.writeFrame(output, responseFrame)
                                }

                                FlatBufferControlProtocol.IncomingMessage.Ping -> {
                                    Log.d(TAG, "FlatBuffer PING received")
                                    val responseFrame =
                                        FlatBufferControlProtocol.buildPongResponse()
                                    FlatBufferFrameIO.writeFrame(output, responseFrame)
                                }

                                FlatBufferControlProtocol.IncomingMessage.StatusRequestMsg -> {
                                    val runtime = ReceiverStateRepository.runtimeState.value
                                    val stateName = runtime.connectionState.name
                                    val deviceName = runtime.deviceName.ifBlank { "UNKNOWN_DEVICE" }
                                    val sourceName = runtime.sourcePcName?.ifBlank { "NONE" } ?: "NONE"

                                    Log.d(TAG, "FlatBuffer STATUS requested")
                                    val responseFrame = FlatBufferControlProtocol.buildStatusResponse(
                                        stateName = stateName,
                                        deviceName = deviceName,
                                        sourceName = sourceName
                                    )
                                    FlatBufferFrameIO.writeFrame(output, responseFrame)
                                }

                                FlatBufferControlProtocol.IncomingMessage.StartStream -> {
                                    val runtime = ReceiverStateRepository.runtimeState.value
                                    val source = runtime.sourcePcName ?: "Unknown PC"
                                    ReceiverStateRepository.setConnected(pcName = source)

                                    Log.d(TAG, "FlatBuffer START_STREAM received")
                                    val responseFrame =
                                        FlatBufferControlProtocol.buildStartStreamResponse()
                                    FlatBufferFrameIO.writeFrame(output, responseFrame)
                                }

                                FlatBufferControlProtocol.IncomingMessage.Disconnect -> {
                                    ReceiverStateRepository.disconnect()

                                    Log.d(TAG, "FlatBuffer DISCONNECT received")
                                    val responseFrame =
                                        FlatBufferControlProtocol.buildDisconnectResponse()
                                    FlatBufferFrameIO.writeFrame(output, responseFrame)
                                }

                                is FlatBufferControlProtocol.IncomingMessage.StreamConfig -> {
                                    val accepted =
                                        message.sampleRate == 48000L &&
                                                message.channels.toInt() == 2 &&
                                                message.frameSamples > 0L

                                    val reason = if (accepted) "OK" else "Unsupported config"

                                    ReceiverStateRepository.updateAudioFormat(
                                        codec = "PCM",
                                        sampleRate = if (accepted) message.sampleRate.toInt() else 48000,
                                        channels = if (accepted) message.channels.toInt() else 2
                                    )

                                    Log.d(
                                        TAG,
                                        "FlatBuffer STREAM_CONFIG received: " +
                                                "rate=${message.sampleRate}, ch=${message.channels}, " +
                                                "fmt=${message.sampleFormat}, codec=${message.codec}, frame=${message.frameSamples}"
                                    )

                                    val responseFrame =
                                        FlatBufferControlProtocol.buildStreamConfigResponse(
                                            accepted = accepted,
                                            sampleRate = if (accepted) message.sampleRate else 48000L,
                                            channels = if (accepted) message.channels else 2,
                                            sampleFormat = message.sampleFormat,
                                            codec = message.codec,
                                            frameSamples = if (accepted) message.frameSamples else 480L,
                                            reason = reason
                                        )

                                    FlatBufferFrameIO.writeFrame(output, responseFrame)
                                }
                            }
                        }
                    } finally {
                        try {
                            socket.close()
                        } catch (_: Exception) {
                        }

                        if (currentControlSocket === socket) {
                            currentControlSocket = null
                        }

                        ReceiverStateRepository.setControlConnection(false)
                    }
                }
            } catch (e: SocketException) {
                Log.d(TAG, "FlatBuffer control server stopped: ${e.message}")
            } catch (e: Exception) {
                ReceiverStateRepository.setError("Control server failed: ${e.message ?: "unknown error"}")
                Log.e(TAG, "FlatBuffer control server failed", e)
            }
        }
    }

    fun disconnectCurrentSession() {
        try {
            currentControlSocket?.close()
        } catch (_: Exception) {
        } finally {
            currentControlSocket = null
        }

        ReceiverStateRepository.setControlConnection(false)
    }

    fun stop() {
        try {
            currentControlSocket?.close()
        } catch (_: Exception) {
        } finally {
            currentControlSocket = null
        }

        try {
            serverSocket?.close()
        } catch (_: Exception) {
        } finally {
            serverSocket = null
        }

        serverJob?.cancel()
        serverJob = null

        scope?.cancel()
        scope = null

        ReceiverStateRepository.setControlConnection(false)
    }

    companion object {
        private const val TAG = "FlatBufferHelloServer"
    }
}